package com.example.onepiece_list_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
